# Dataset
This folder contains the scraped data from Kayak for the period from 2022-02-01 to 2022-04-30 including the following 12 routes:

- RUH => NYC
- RUH => SVO
- RUH => PAR
- NYC => RUH
- NYC => SVO
- NYC => PAR
- SVO => PAR
- SVO => RUH
- SVO => NYC
- PAR => NYC
- PAR => RUH
- PAR => SVO 

This data was used to train the models of the project.
